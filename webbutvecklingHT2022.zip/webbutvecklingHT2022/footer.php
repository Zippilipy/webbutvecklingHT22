 <footer>
            <p>någon text</p>
        </footer>
    </body>
</html>